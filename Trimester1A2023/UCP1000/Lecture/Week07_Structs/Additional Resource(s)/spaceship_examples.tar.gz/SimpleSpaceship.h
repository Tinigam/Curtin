struct SpaceShip
{
	char name[256];
	double velocity;
};
