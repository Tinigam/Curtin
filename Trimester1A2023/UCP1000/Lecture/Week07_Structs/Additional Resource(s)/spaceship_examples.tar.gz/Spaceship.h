typedef struct SpaceShip
{
	char name[256];
	double velocity;
} spaceship_t;
