#!/bin/bash

#run "myProgram" with "12345" as argv and "54321" as user input
echo "54321" | ./myProgram "12345"