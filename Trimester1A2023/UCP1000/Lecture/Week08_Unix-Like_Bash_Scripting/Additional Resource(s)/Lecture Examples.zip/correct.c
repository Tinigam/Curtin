#include <stdio.h>

int main()
{
	printf("this program finishes correctly\n");
	return 0;
}
