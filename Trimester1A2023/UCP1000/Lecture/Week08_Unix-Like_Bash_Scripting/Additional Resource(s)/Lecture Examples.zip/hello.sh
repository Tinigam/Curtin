#!/bin/bash
echo 'Hello World!'
echo 'Scripting is like programming but not.'
echo "The first three arguments are $1, $2 and $3"

