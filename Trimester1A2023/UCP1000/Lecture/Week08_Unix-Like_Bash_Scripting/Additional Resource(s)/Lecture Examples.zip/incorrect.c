#include <stdio.h>

int main()
{
	printf("this program does not finish correctly\n");
	return 1;
}
