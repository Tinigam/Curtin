instring = "A Moose Once Bit My Sister"
variable1 = 5 < 10 and 5 > 10 
variable2 = (len(instring)-1*15) 
variable3 = input("Enter a number:") 
variable4 = 12 % 5 / 3 
variable5= 10/3 * 14.0

print(variable1, "is a Boolean\n",variable2, "is a Integer\n", variable3, "is a String\n" ,variable4, "is a Float\n",variable5, "is a Float")
# variable1 is a Boolean
# variable2 is a Integer
# variable3 is a String
# variable4 is a Float
# variable5 is a Float