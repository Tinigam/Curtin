def Strfun(instring):
  instring = instring.lower()
  result = instring[::-2]
  return result

