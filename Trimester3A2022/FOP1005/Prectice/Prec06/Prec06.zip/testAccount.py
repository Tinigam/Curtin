from BankAccount import *

bank1 =BankAccount("Everyday", "007", 2000)
print("withdraw 100")
bank1.withdraw(100)
print("balance: $", bank1.balance)
print("deposit 200")
bank1.deposit(200)
print("balance: $", bank1.balance)
print("add interest")
bank1.add_interest
print("balance: $", bank1.balance)
print()

