from animals import Cat
from animals import Dog
from animals import Bird
garfield = Cat("Garfield", "1/1/1978", "Orange", "Tabby")
garfield.printit()
print(garfield)

dude = Dog("Dude", "1/1/2011", "Brown", "Jack Russell")
oogs = Cat("OOgie", "1/1/2006", "Grey", "Fluffy")
bbird = Bird("BigBird", "10/11/1969", "Yellow", "Canary")

dude.printit()
oogs.printit()
bbird.printit()